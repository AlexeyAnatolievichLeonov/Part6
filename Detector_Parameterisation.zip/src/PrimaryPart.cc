#include <PrimaryPart.hh>

PrimaryPart::PrimaryPart(std::ofstream& ofsa)
{
 GProton = new G4ParticleGun(1);
 GProton->SetParticleDefinition(G4Proton::ProtonDefinition());
 GProton->SetParticleEnergy(100. * MeV);
// GNeutron = new G4ParticleGun(1);
// GNeutron->SetParticleDefinition(G4Neutron::NeutronDefinition());

//gunMes = new GunMes(this);
 this->f_prim=&ofsa;
 (*f_prim) << std::setw(12) << "Hi from PrimaryPart!" << std::endl;
}

PrimaryPart::~PrimaryPart() 
{
 (*f_prim) << std::setw(12) << "Bye from PrimaryPart!" << std::endl;
}

//��������� ���������
void PrimaryPart::GeneratePrimaries(G4Event* anEvent) 
{
 //GProton->SetParticleEnergy(100. * MeV);
 GProton->SetParticlePosition(G4ThreeVector(0*mm , 0*mm, -5.*cm));
// GGamma->SetParticlePosition(G4ThreeVector(0, 0, 0));
 GProton->SetParticleMomentumDirection(G4ThreeVector(0, 0, 1));
 GProton->GeneratePrimaryVertex(anEvent);
 
// GNeutron->SetParticleEnergy(14. * MeV);
// GNeutron->SetParticlePosition(G4ThreeVector(0*mm , 0*mm, -21.*cm));
// GNeutron->SetParticleMomentumDirection(G4ThreeVector(0, 0, 1));
// GNeutron->GeneratePrimaryVertex(anEvent);
 
}

//GunMes::~GunMes() {};
